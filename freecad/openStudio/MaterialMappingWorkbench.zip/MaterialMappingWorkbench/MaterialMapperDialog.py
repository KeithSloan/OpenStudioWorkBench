
from PySide2 import QtWidgets, QtCore

class MaterialMapperDialog(QtWidgets.QDialog):
    def __init__(self, materials, standard_materials):
        super().__init__()
        self.setWindowTitle("Map gbXML Materials")
        self.materials = materials
        self.standard_materials = standard_materials
        self.mapping = {}
        self.init_ui()

    def init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        self.form_widgets = {}

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        inner = QtWidgets.QWidget()
        form_layout = QtWidgets.QFormLayout(inner)

        for mat in self.materials:
            wid = QtWidgets.QWidget()
            wid_layout = QtWidgets.QVBoxLayout()

            combo = QtWidgets.QComboBox()
            combo.addItem("Custom")
            for name, _ in self.standard_materials:
                combo.addItem(name)

            prop_inputs = {}
            for prop in ["Thickness", "Conductivity", "Density", "Specific Heat"]:
                inp = QtWidgets.QLineEdit()
                inp.setPlaceholderText(prop)
                wid_layout.addWidget(QtWidgets.QLabel(prop))
                wid_layout.addWidget(inp)
                prop_inputs[prop] = inp

            combo.currentTextChanged.connect(lambda val, p=prop_inputs: self.toggle_custom_fields(val, p))
            wid_layout.insertWidget(0, combo)
            wid.setLayout(wid_layout)
            form_layout.addRow(f"{mat['name']} ({mat['id']})", wid)

            self.form_widgets[mat["id"]] = {
                "combo": combo,
                "inputs": prop_inputs
            }

        scroll.setWidget(inner)
        layout.addWidget(scroll)

        save_btn = QtWidgets.QPushButton("Save")
        save_btn.clicked.connect(self.save_mapping)
        layout.addWidget(save_btn)

    def toggle_custom_fields(self, selected, prop_inputs):
        for key, field in prop_inputs.items():
            field.setEnabled(selected == "Custom")

    def save_mapping(self):
        for mat in self.materials:
            data = self.form_widgets[mat["id"]]
            choice = data["combo"].currentText()
            if choice == "Custom":
                props = {}
                for k, field in data["inputs"].items():
                    try:
                        props[k] = float(field.text())
                    except ValueError:
                        props[k] = None
                self.mapping[mat["id"]] = {"type": "custom", "properties": props}
            else:
                self.mapping[mat["id"]] = {"type": "standard", "name": choice}
        self.accept()

    def get_mapping(self):
        return self.mapping
